module.exports = {
  tokens: "8515680319:AAEcnIVYO1Q5eKA9QdMw-tbAdtH9ncsVfxI",  // Masukin Bot token kamu
  owners: "8584308370", // Masukin ID Telegram kamu
  port: "4491", // Masukin Port panel kamu 
  ipvps: "http://sadxx.zonapanel.web.id" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};

/* WAJIB BACA !!!
 cari di index.js halaman 1710-1711 di situ masukin bot token sama id tele lu.

 emngnya knpa bang?
 lu buka aja dulu. di sana udah gw kasi penjelasannya
*/